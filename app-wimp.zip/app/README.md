# @rneui/template

## React Native Elements Expo Template

### Usage

#### Stable

        expo init app --template @rneui/template

#### Stable Typescript

        expo init app --template @rneui/template@ts

#### Bleeding Edge (Experimental)

        expo init app --template @rneui/template@edge

#### Bleeding Edge Typescript (Experimental)

        expo init app --template @rneui/template@edge-ts
