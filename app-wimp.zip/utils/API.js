export const API = {
  API_URL: "http://proj14.ruppin-tech.co.il/api/",
  API_Product_In_Branch_Comp:"http://proj14.ruppin-tech.co.il/api/Products_In_Branch/comp/",
};
